<table class="table table-bordered table-hover mb-0 datatable" id="cucianTable">
    <thead>
        <tr class="text-white"style="background-color: #9E7676">
            <th>no</th>
            <th>Kode cucian</th>
            <th>Nama cucian</th>
            <th>Harga cucian</th>
            <th>Jenis cucian</th>
            <th>Deskripsi cucian</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cucian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cucian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($cucian->kode_cucian); ?></td>
                <td>Rp.<?php echo e(number_format($cucian->price)); ?></td>
                <td><?php echo e($cucian->jenis->name); ?></td>
                <td><?php echo e($cucian->description); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/cucian/export_excel.blade.php ENDPATH**/ ?>