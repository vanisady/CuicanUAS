<body>
    <div class="d-flex">
        <a href="<?php echo e(route('cucian.show', ['cucian' => $cucian->id])); ?>"
            class="btn btn-outline-light bg-info btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
        <a href="<?php echo e(route('cucian.edit', ['cucian' => $cucian->id])); ?>"
            class="btn btn-outline-warning btn-sm me-2"><i class="bi-pencil-square"></i></a>
        <div>
            <form action="<?php echo e(route('cucian.destroy', ['cucian' => $cucian->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-outline-danger btn-sm me-2 btn-delete"
                    data-name="<?php echo e($cucian->kode_cucian . ' ' . $cucian->nama_cucian); ?>">
                    <i class="bi-trash"></i>
                </button>
            </form>
        </div>
    </div>
</body>
<?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/cucian/action.blade.php ENDPATH**/ ?>