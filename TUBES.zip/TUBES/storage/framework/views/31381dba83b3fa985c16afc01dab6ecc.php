<?php $__env->startSection('content'); ?>
    <section class="section-content">
        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_cucian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="projcard-container">
            <div class="projcard projcard-blue">
              <div class="projcard-innerbox">
                <img class="projcard-img" src="<?php echo e(Vite::asset('resources/images/cucian.png')); ?>" />
                <div class="projcard-textbox">
                  <div class="projcard-title"> <?php echo e($jenis_cucian->name); ?></div>
                  <?php $__currentLoopData = $laundry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cucian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($cucian->jenis->id === $jenis_cucian->id): ?>
                  <a href="<?php echo e(route('show', ['id' => $cucian->id])); ?>" style="text-decoration:none">
                  <div class="projcard-subtitle"> </div>
                  <div class="projcard-bar"></div>
                  <div class="projcard-description">  <?php echo e($jenis_cucian->description); ?>  </div></a>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="projcard-tagbox">
                    <span class="projcard-tag"><?php echo e($jenis_cucian->code); ?></span>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

    </section>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/default.blade.php ENDPATH**/ ?>