<nav class="navbar navbar-expand-md navbar-dark  bg-dark shadow-xl" >
    <div class="container">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav me-auto">
                <?php
                    $currentRouteName = Route::currentRouteName();
                ?>
                <img class="img-fluid " src="<?php echo e(Vite::asset('resources/images/cucian.png')); ?>"alt="image"
                    style="width: 60px;">
                <div class="collapse navbar-collapse fw-bold" id="navbarSupportedContent">
                    
                    <ul class="navbar-nav flex-row flex-wrap">
                        <li class="nav-item col-2 col-md-auto"><a href="<?php echo e(route('home')); ?>"
                                class="nav-link <?php if($currentRouteName == 'home'): ?> active <?php endif; ?>">Home</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav flex-row flex-wrap">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item col-2 col-md-auto"><a href="<?php echo e(route('cucian.index')); ?>"
                                    class="nav-link <?php if($currentRouteName == 'cucian.index'): ?> active <?php endif; ?>">Daftar
                                    Cucian</a>
                            </li>

                            <li class="nav-item col-2 col-md-auto"><a href="<?php echo e(route('comPro')); ?>" class="nav-link <?php if($currentRouteName == 'comPro'): ?> active <?php endif; ?>">Profile perusahaan</a>
                            </li>
                        <?php endif; ?>
                    </ul>
            </ul>
            <!-- Right Side Of Navbar -->

            <ul class="navbar-nav ms-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>


                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="dropdown-toggle btn btn-outline-light my-2 ms-md-auto" href="#"
                            role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><i
                                class="bi-person-circle"></i>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="bi-person-fill"></i>
                                <?php echo e(__('My profile')); ?></a>
                            <hr>
                            <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();"><i
                                    class="bi bi-lock"></i>
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/layouts/nav.blade.php ENDPATH**/ ?>