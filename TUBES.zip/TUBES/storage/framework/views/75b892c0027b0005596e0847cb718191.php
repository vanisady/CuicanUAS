<?php $__env->startSection('content'); ?>
    <div class="container-sm my-5">
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 col-xl-4 border">
                <div class="mb-3 text-center">
                    <img class="img-fluid bg-light rounded-circle"
                        src="<?php echo e(Vite::asset('resources/images/cucian.png')); ?>"alt="image" style="width: 100px;">
                    <h4><?php echo e($pageTitle); ?></h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="kodeCucian" class="form-label">Kode Cucian</label>
                        <h5><?php echo e($cucian->kode_cucian); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="harga" class="form-label">Harga Cucian</label>
                        <h5>Rp.<?php echo e(number_format($cucian->price)); ?>/KG</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="deskripsiCucian" class="form-label">Deskripsi Cucian</label>
                        <h5><?php echo e($cucian->description); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="satuan" class="form-label">Jenis Cucian</label>
                        <h5><?php echo e($cucian->jenis->name); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="img" class="form-label"><img src="<?php echo e(Vite::asset('storage/app/public/files/' . $cucian->encrypted_filename)); ?>"
                            style="width: 100%"></label>
                        <?php if($cucian->original_filename): ?>

                            <a href="<?php echo e(route('cucian.downloadFile', ['cucianId' => $cucian->id])); ?>"
                                class="btn btn-primary btn-sm mt-2">
                                <i class="bi bi-download me-1"></i> Download Gambar
                            </a>
                        <?php else: ?>
                            <h5>Tidak ada</h5>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 d-grid">
                        <a href="<?php echo e(URL::PREVIOUS()); ?>" class="btn btn-outline-dark btn-lg mt-3"><i
                                class="bi-arrow-left-circle me-2"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>


</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/cucian/show.blade.php ENDPATH**/ ?>