<?php $__env->startSection('content'); ?>
<div class="tentangKami">
 <h1>Tentang Kami</h1>
 <img src="<?php echo e(Vite::asset('resources/images/cucian.png')); ?>" alt="img">
 <p> Website Cucian merupakan salah satu website umkm yang menampilkan catalog
    yang berisi jasa laundry dengan harga murah dan terjangkau dengan cepat dan akurat.
 </p>
 <p><a href="https://wa.me/081216358619">Contact us !!</a></p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LaVoid\KULIAH\Framework\TUBES\resources\views/ComPro.blade.php ENDPATH**/ ?>