<nav class="navbar navbar-expand-md navbar-dark  bg-dark shadow-xl" >
    <div class="container">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav me-auto">
                @php
                    $currentRouteName = Route::currentRouteName();
                @endphp
                <img class="img-fluid " src="{{ Vite::asset('resources/images/cucian.png') }}"alt="image"
                    style="width: 60px;">
                <div class="collapse navbar-collapse fw-bold" id="navbarSupportedContent">
                    {{-- <hr class="d-md-none text-white-50"> --}}
                    <ul class="navbar-nav flex-row flex-wrap">
                        <li class="nav-item col-2 col-md-auto"><a href="{{ route('home') }}"
                                class="nav-link @if ($currentRouteName == 'home') active @endif">Home</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav flex-row flex-wrap">
                        @Auth
                            <li class="nav-item col-2 col-md-auto"><a href="{{ route('cucian.index') }}"
                                    class="nav-link @if ($currentRouteName == 'cucian.index') active @endif">Daftar
                                    Cucian</a>
                            </li>

                            <li class="nav-item col-2 col-md-auto"><a href="{{ route('comPro') }}" class="nav-link @if ($currentRouteName == 'comPro') active @endif">Profile perusahaan</a>
                            </li>
                        @endauth
                    </ul>
            </ul>
            <!-- Right Side Of Navbar -->

            <ul class="navbar-nav ms-auto">
                <!-- Authentication Links -->
                @guest


                    @if (Route::has('login'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                    @endif

                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @endguest
                @Auth
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="dropdown-toggle btn btn-outline-light my-2 ms-md-auto" href="#"
                            role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><i
                                class="bi-person-circle"></i>
                            {{ Auth::user()->name }}
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('profile') }}"><i class="bi-person-fill"></i>
                                {{ __('My profile') }}</a>
                            <hr>
                            <a class="dropdown-item text-danger" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();"><i
                                    class="bi bi-lock"></i>
                                {{ __('Logout') }}
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </li>
                @endauth
            </ul>
        </div>
    </div>
</nav>
