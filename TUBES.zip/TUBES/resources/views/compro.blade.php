@extends('layouts.app')

@section('content')
<div class="tentangKami">
 <h1>Tentang Kami</h1>
 <img src="{{ Vite::asset('resources/images/cucian.png') }}" alt="img">
 <p> Website Cucian merupakan salah satu website umkm yang menampilkan catalog
    yang berisi jasa laundry dengan harga murah dan terjangkau dengan cepat dan akurat.
 </p>
 <p><a href="https://wa.me/081216358619">Contact us !!</a></p>
</div>

@endsection
