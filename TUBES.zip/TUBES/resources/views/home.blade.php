@extends('layouts.app')
@section('content')
    @include('default')
@endsection
@vite('resources/js/app.js')
