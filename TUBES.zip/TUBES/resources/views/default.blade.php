@extends('layouts.app')

@section('content')
    <section class="section-content">
        @foreach ($jenis as $jenis_cucian)
        <div class="projcard-container">
            <div class="projcard projcard-blue">
              <div class="projcard-innerbox">
                <img class="projcard-img" src="{{ Vite::asset('resources/images/cucian.png')}}" />
                <div class="projcard-textbox">
                  <div class="projcard-title"> {{ $jenis_cucian->name }}</div>
                  @foreach ($laundry as $cucian)
                  @if ($cucian->jenis->id === $jenis_cucian->id)
                  <a href="{{ route('show', ['id' => $cucian->id]) }}" style="text-decoration:none">
                  <div class="projcard-subtitle"> </div>
                  <div class="projcard-bar"></div>
                  <div class="projcard-description">  {{ $jenis_cucian->description }}  </div></a>
                  @endif
                  @endforeach
                  <div class="projcard-tagbox">
                    <span class="projcard-tag">{{$jenis_cucian->code}}</span>
                  </div>
                </div>
              </div>
            </div>
            @endforeach
          </div>

    </section>
@endsection
</html>
