<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Employee List</title>
    <style>
        html {
            font-size: 12px;
        }

        .table {
            border-collapse: collapse !important;
            width: 100%;
        }

        .table-bordered th,
        .table-bordered td {
            padding: 0.5rem;
            border: 1px solid black !important;
        }
    </style>
</head>
<body>
    <h1>Daftar Cucian</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
               <th>no</th>
            <th>Kode cucian</th>
            <th>Nama cucian</th>
            <th>Harga cucian</th>
            <th>Jenis cucian</th>
            <th>Deskripsi cucian</th>
            </tr>
        </thead>
        <tbody>
             @foreach ($cucian as $index => $cucian)
            <tr>
                <td align="center">{{ $index + 1 }}</td>
                <td>{{ $cucian->kode_cucian }}</td>
                <td align="center">Rp.{{ number_format($cucian->price) }}</td>
                <td>{{ $cucian->jenis->name }}</td>
                <td>{{ $cucian->description }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</body>
</html>
