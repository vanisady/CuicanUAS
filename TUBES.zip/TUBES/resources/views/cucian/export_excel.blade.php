<table class="table table-bordered table-hover mb-0 datatable" id="cucianTable">
    <thead>
        <tr class="text-white"style="background-color: #9E7676">
            <th>no</th>
            <th>Kode cucian</th>
            <th>Nama cucian</th>
            <th>Harga cucian</th>
            <th>Jenis cucian</th>
            <th>Deskripsi cucian</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($cucian as $index => $cucian)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $cucian->kode_cucian }}</td>
                <td>Rp.{{ number_format($cucian->price) }}</td>
                <td>{{ $cucian->jenis->name }}</td>
                <td>{{ $cucian->description }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
