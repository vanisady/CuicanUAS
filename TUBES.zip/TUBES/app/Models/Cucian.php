<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Cucian extends Model
{
    use HasFactory;
    protected $table='cucian';
    public function jenis()
    {
        return $this->belongsTo(Jenis::class,'jenis_id','id');
    }

}
