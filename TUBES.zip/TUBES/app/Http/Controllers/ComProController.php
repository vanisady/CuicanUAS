<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ComProController extends Controller
{

    public function __invoke(Request $request)
    {
        $pageTitle = 'ComPro';

        return view(('ComPro'), ['pageTitle' => $pageTitle]);
    }
}
