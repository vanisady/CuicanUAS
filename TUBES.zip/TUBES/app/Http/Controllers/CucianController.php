<?php

namespace App\Http\Controllers;


use PDF;
use Illuminate\Support\Str;
use App\Models\Jenis;
use App\Models\Cucian;
use Illuminate\Http\Request;
use App\Exports\CucianExport;
use App\Http\Controllers\Controller;
use Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;

class Cuciancontroller extends Controller
{
    /**
     * Display a jenising of the resource.
     */

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $pageTitle = 'Daftar Cucian';
        confirmDelete();
        return view('cucian.index', compact('pageTitle'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $pageTitle = 'Input Data Cucian';
        $jenis = Jenis::all();
        return view('cucian.create', compact('pageTitle', 'jenis'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :Attribute dengan angka',
            'unique' => ':Attribute sudah ada'
        ];
        $validator = Validator::make($request->all(), [
            'kodeCucian' => 'required|unique:cucian,kode_cucian',
            'harga' => 'required|numeric',
            'deskripsiCucian' => 'required',
        ], $messages);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $file = $request->file('img');

        if ($file != null) {
            $originalFilename = $file->getClientOriginalName();
            $encryptedFilename = $file->hashName();

            //Store File
            $file->store('public/files');
        }
        // ELOQUENT
        $cucian = new Cucian;
        $cucian->kode_cucian = $request->kodeCucian;

        $cucian->price = $request->harga;
        $cucian->description = $request->deskripsiCucian;
        $cucian->jenis_id = $request->jenis;

         if ($file != null) {
            $cucian->original_filename = $originalFilename;
            $cucian->encrypted_filename = $encryptedFilename;
        }
        $cucian->save();


        Alert::success('Berhasil ditambahkan', 'Data Cucian berhasil ditambahkan.');
        return redirect()->route('cucian.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $pageTitle = ' Detail Cucian';
        // ELOQUENT
        $cucian = Cucian::find($id);
        return view('cucian.show', compact('pageTitle', 'cucian', ));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $pageTitle = 'Edit Cucian';
        // ELOQUENT
        $jenis = Jenis::all();
        $cucian = Cucian::find($id);
        return view(
            'cucian.edit',
            compact(
                'pageTitle',
                'jenis',
                'cucian'
            )
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka',
            'unique' => ':Attribute sudah ada'
        ];
        $validator = Validator::make($request->all(), [
            'kodeCucian' => 'required|unique:cucian,kode_cucian,' . $id,
            'harga' => 'required|numeric',
            'deskripsiCucian' => 'required',
        ], $messages);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        // ELOQUENT
        $cucian = Cucian::find($id);
        $file = $request->file('img');

        if ($file != null) {
            $originalFilename = $file->getClientOriginalName();
            $encryptedFilename = $file->hashName();

            Storage::disk('public')->delete('files/' . $cucian->encrypted_filename);

            $file->store('public/files');
        }



        $cucian->kode_cucian = $request->kodeCucian;
        $cucian->price = $request->harga;
        $cucian->description = $request->deskripsiCucian;
        $cucian->jenis_id = $request->jenis;
        if ($file != null) {
            $cucian->original_filename = $originalFilename;
            $cucian->encrypted_filename = $encryptedFilename;
        }
        $cucian->save();
        Alert::success('Berhasil diedit', 'Data Cucian berhasil diedit.');
        return redirect()->route('cucian.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $cucian=Cucian::find($id);
        $deletionpath = 'public/files/' . $cucian->encrypted_filename;
        Storage::delete($deletionpath);
        $cucian->delete();
        Alert::success('Berhasil dihapus', 'Data Cucian berhasil dihapus.');
        return redirect()->route('cucian.index');
    }

    public function getData(Request $request)
    {
        $cucians =  Cucian::with('jenis');
        if ($request->ajax()) {
            return datatables()->of($cucians)
                ->addIndexColumn()
                ->addColumn('action', function ($cucian) {
                    return view('cucian.action', compact('cucian'));
                })
                ->toJson();
        }
    }

    public function exportExcel()
    {
        return Excel::download(new CucianExport, 'cucian.xlsx');
    }

    public function exportPdf()
    {
        $cucian = Cucian::all();

        $pdf = PDF::loadView('cucian.export_pdf', compact('cucian'));

        return $pdf->download('cucian.pdf');
    }

    public function downloadFile($cucianId)
    {
        $cucian = Cucian::find($cucianId);
        $encryptedFilename = 'public/files/' . $cucian->encrypted_filename;
        $downloadFilename = Str::lower($cucian->kode_cucian . '_' . $cucian->price . '.jpg');

        if (Storage::exists($encryptedFilename)) {
            return Storage::download($encryptedFilename, $downloadFilename);
        }
    }
}

