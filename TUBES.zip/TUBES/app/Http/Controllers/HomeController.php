<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cucian;
use App\Models\Jenis;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $laundry = Cucian::all();
        $jenis = Jenis::all();
        $pageTitle = 'Home';
        return view('home', compact('pageTitle', 'laundry','jenis'));

    }
    public function show(string $id)
    {
        $pageTitle = ' Detail Cucian';
        // ELOQUENT
        $cucian = Cucian::find($id);
        return view('cucian.show', compact('pageTitle', 'cucian', ));
    }
}
