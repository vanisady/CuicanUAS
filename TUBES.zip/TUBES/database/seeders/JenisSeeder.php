<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JenisSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('jenis')->insert([
            [
                'code' => 'CK',
                'name' => 'Cuci Kering',
                'description' => 'Cuci Kering merupakan salah satu layanan kami yang terbaik di ketintunk'
            ],
            [
                'code' => 'CB',
                'name' => 'Cuci Basah',
                'description' => 'Cuci Basah merupakan salah satu layanan kami yang termurah dan cocok untuk anak kost di ketintunk'
            ],
            [
                'code' => 'CKS',
                'name' => 'Cuci Kering Setrika',
                'description' => 'Cucian Kering Setrika merupakan salah satu layanan kami yang terbaik di ketintunk'
            ],
        ]);
    }
}
