<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CucianSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('cucian')->insert([
             [
                'kode_cucian' => 'CK-1',
                'price' => '5000',
                'jenis_id' => 1,
                'description' => '',
            ],
            [
                'kode_cucian' => 'CB-1',
                'price' => '4000',
                'jenis_id' => 2,
                'description' => '',
            ],
            [
                'kode_cucian' => 'CKS-1',
                'price' => '7000',
                'jenis_id' => 3,
                'description' => '',
            ],
        ]);
    }
}
